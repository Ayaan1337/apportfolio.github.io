if(($iday >= $inday  && $iday <= $outday) ||  ($oday >= $inday  && $oday<= $outday))
			{
				$rs = $rs + $res[2];
			}




body-----#C8884A

body1-----#B87637

td------#D5A787